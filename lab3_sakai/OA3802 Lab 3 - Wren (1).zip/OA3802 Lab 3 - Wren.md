## Lab Scenario

In 2018, Pew Research discovered that social media outpaced print media as a primary source for news within the US. Social media platforms have become near ubiquitous and we see their usage permeate many areas of societal communication: politics, pop culture, etc.. We have even seen major, dramatic events unfold in real-time in social media (OBL Raid).

As a Data Scientist, you are curious to gain an understanding into how to access such sources IOT gain potential insights and to determine if such sources are useful or not. While the opportunity to access and play with nearly unlimited data in JSON form is quite appealing to a data scientist, questions linger about the viability of using such a source for primary research. Please see the following article discussing the proliferation of bot actors in social media, while also pointing to limitations of social media in its representativeness (Schuchard et al.) [https://link.springer.com/article/10.1007/s41109-019-0164-x]

Your focus is to gain an initial understanding of how to acquire large volumes of JSON data via distinct API processes. From there, you want to test your data cleaning skills to enable the application of specific text mining / NLP methods.

## Tasks

#### Task 1: Schedule Tweet Harvest from Standard API (20 points)
To complete Task 1, you will create a `python` script that will query a hashtag (or keyword) of your choice from Twitter using the `tweepy` module. You will create a `cron` job via your `crontab` that will automatically run your `.py` script once per hour for 3 total hours. Retrieve 100 tweets with each Standard API query (i.e. count = 100).

#### Task 2: Extract and Analyze (30 points)
Using either `python` or `r`, you must determine the top 20 most frequent terms used across all of the text fields from the tweet corpus.

#### Task 3: Determine the Sentiment of Streaming Sample (35 points)
Determine the sentiment of the TOTAL text element for each tweet.   If a word does not exist in the AFINN-111 corpus, then you will rate it as a zero (or the total field if absent any matching words).

#### Task 4: Analyze and Assess: (30 points)
Now that we have a sentiment value for each tweet (or most tweets) can you determine why there exists such a positive/negative/neutral sentiment for your corpus? You can evaluate based on frequency of terms and events taking place in the real world. Conduct such an analysis to derive some insights and provide your analysis steps. Finally, report on your thoughts as to the effectiveness (or ineffectiveness) of technique like sentiment analysis applied to the data sample we are evaluating.

You will have to submit the following for this task:

1. StreamSample.txt file of tweets
2. Completed R or python code to derive sentiment
3. A sample output of at least 10 tweets showing their scored sentiment displayed on your html document

## Tutorial

#### Task 1
Twitter provides an API, which may be used to gather its data with relative ease.  To do so, you must first apply for a developer account and once approved, they'll provide tokens and keys that are unique to your account.  From there, you can begin querying tweets based off of words or hash tags.  Check out the following [link](http://docs.tweepy.org/en/latest/) for documentation on the `tweepy` package.  An important note is to ensure `wait_on_rate_limit=True` to avoid having your credentials revoked in response to overloading their system.


```python
# Required Python libraries
import tweepy
import datetime
import csv
import pandas as pd
import warnings
import regex as re
warnings.filterwarnings('ignore')

# Authentication keys/tokens (STS dev)
consumer_key = XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
consumer_secret = XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

token = XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
token_secret = XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

# Authorization variable
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(token, token_secret)

# Packaged API call information
api = tweepy.API(auth, wait_on_rate_limit=True)
```

Now that our Twitter credentials are established, we can begin our Twitter search.  The `tweepy` package is the preeminent Twitter scraping [package](http://docs.tweepy.org/en/latest/) in Python.  You can search individual users, search by hashtags, or in this case, use the `tweepy.Cursor()` method to search for a specific keyword.  To filter only English results, use the `lang="en"` and to extract the full text, use `tweet_mode="extended"`.  Lastly, to remove retweets, use `q="whatever_you_want_to_search_for -filter:retweets"`.  From there, we can extract the user's screen name/handle, their location, time created, and the message.  One important note is that the user's location is what they report or don't report.  For example, a user could be in New York but list their location as California.  

Now that we have data in a list, we can easily convert into a data frame then export it into a CSV.  


```python
# Using the Cursor object (great documentation available)
tweets = tweepy.Cursor(api.search,
                           q="#BLM -filter:retweets",
                           count=100,
                           lang="en", tweet_mode='extended').items(100)

# Code sourced from: https://www.earthdatascience.org/courses/use-data-open-source-python/intro-to-apis/twitter-data-in-python/
# Uses list comprehension to create a list of a user name, location, DTG, and the message
tweet_data = [[tweet.user.screen_name, tweet.user.location, tweet.created_at, tweet.full_text] for tweet in tweets]

            
# Create a data frame with the tweet's poster/handle, location (if provided), date-time group, and the message
tweet_df = pd.DataFrame(data=tweet_data, columns=['User', "Location", "DTG", "Message"])

# Create a string for file name
filename = 'twitter_data_analysis '+(datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S"))+'.csv'

# Export to CSV
tweet_df.to_csv(filename)
```

Once the Twitter script is established, we can schedule the `.py` file using `crontab`, which provides system automation capabilities.  The following [link](https://crontab.guru/#*_*_*_*_*) provides a template for ensuring the appropriate schedule. To edit a process, use the `crontab -e` command and to see a list of current `cron` jobs you can use the `crontab -l` command.  The figure below depicts the fields and associated parameters


```python
# Code sourced from: https://opensource.com/article/17/11/how-use-cron-linux

# Example of job definition:
# .---------------- minute (0 - 59)
# |  .------------- hour (0 - 23)
# |  |  .---------- day of month (1 - 31)
# |  |  |  .------- month (1 - 12) OR jan,feb,mar,apr ...
# |  |  |  |  .---- day of week (0 - 6) (Sunday=0 or 7) OR sun,mon,tue,wed,thu,fri,sat
# |  |  |  |  |
# *  *  *  *  * user-name  command to be executed
```

Unfortunately, `crontab` is not easily implemented in Windows due to security restrictions.  However, I am including code below that depicts what syntax you would employ given the lab requirements.

`0 15-17 22 10 5 python3 /mnt/c/Users/david/Documents/Operations\ Research/Q6/OA3802/Labs/lab3_sakai OA3802_Twitter_Script.py`

Using the figure above, the code executes from 1500-1700 on the hour (i.e. 1500, 1600, & 1700) on Thursday October 22nd.  The second half uses `python3` then sources to the path of the applicable script `OA3802_Twitter_Script.py`.

Despite the `crontab` failing to run, you can run the `python` script from the bash shell for three hours and produce individual CSVs.

#### Task 2

Now that you have created three CSVs containing 100 tweets, you can concatenate the data frames and then extract the messages for sentiment analysis.


```python
# Read in each Twitter CSV
tweet_df1 = pd.read_csv('twitter_data_analysis 2020-10-27-17-38-08.csv')
tweet_df2 = pd.read_csv('twitter_data_analysis 2020-10-27-18-38-30.csv')
tweet_df3 = pd.read_csv('twitter_data_analysis 2020-10-27-19-38-05.csv')

# Concatenate
concat_tweet_df = pd.concat([tweet_df1, tweet_df2, tweet_df3])

# Extract all 300 messages into one list
tweet_list = concat_tweet_df['Message'].to_list()
```

Now that we have all 300 tweets in one list, we can analyze all of the tweets in total.  Data cleaning needs to occur as some tweets contain emojis and some are tweeted at other users.  Additionally, each tweet contains a link that needs to be removed.


```python
# Necessary libraries
import nltk
import re
```


```python
# Code sourced from: https://stackoverflow.com/questions/20078816/replace-non-ascii-characters-with-a-single-space
# Create an empty list for storage
temp_list = []
i = 0 # Initialize a counter
while i < len(tweet_list): # Iterate over a list
    temp_list.append(re.sub(r'[^\x00-\x7F]+',' ', tweet_list[i])) # Remove all non-ASCII characters
    i += 1 # Increment the counter

# Code sourced from: https://stackoverflow.com/questions/11331982/how-to-remove-any-url-within-a-string-in-python
# Create an empty list for storage
clean_list = [] 
j = 0 # Initialize a counter
while j < len(temp_list): # Iterate over a list
    clean_list.append(re.sub(r'http\S+', '', temp_list[j], flags=re.MULTILINE)) # Remove any URL
    j += 1 # Increment a counter
    
# Code sourced from: https://stackoverflow.com/questions/5618878/how-to-convert-list-to-string
# Creates one long string of data
tweet_str = ''.join(str(e) for e in clean_list)

# Code sourced from OA3802_lsn10
# tokenize text
tokens_TI = nltk.word_tokenize(tweet_str)

# remove all tokens that are not alphabetic (i.e. punctuation)
words = [word for word in tokens_TI if word.isalpha()]

# put all words to lower case
words = [w.lower() for w in words]

from nltk.corpus import stopwords
stop_words = stopwords.words('english')

# Remove stops words from our TI token list
words = [w for w in words if not w in stop_words]

# Determines the frequency for each token
TI_freqs = nltk.FreqDist(words)

# Determine the top 20 terms
n = 20
TI_dict = dict(TI_freqs.most_common(n))

# Depict the top 20 terms
TI_dict
```




    {'blm': 284,
     'vote': 48,
     'blacklivesmatter': 37,
     'police': 35,
     'people': 34,
     'black': 33,
     'philadelphia': 26,
     'amp': 24,
     'protests': 22,
     'antifa': 22,
     'joebiden': 20,
     'trump': 18,
     'like': 17,
     'stop': 17,
     'philly': 16,
     'biden': 15,
     'get': 15,
     'one': 15,
     'lives': 14,
     'looting': 14}




```python
# Take a bi-gram perspective
bigrams = nltk.bigrams(words)

#compute frequency distribution for all the bigrams in the text
bigrams_freq = nltk.FreqDist(bigrams)

# Depict the top 20 bigrams
bigrams_freq.most_common(n)
```




    [(('blm', 'blacklivesmatter'), 20),
     (('blacklivesmatter', 'blm'), 10),
     (('blm', 'antifa'), 10),
     (('walter', 'wallace'), 9),
     (('black', 'people'), 9),
     (('black', 'lives'), 9),
     (('stop', 'killing'), 8),
     (('killing', 'black'), 8),
     (('protests', 'blm'), 7),
     (('breonna', 'taylor'), 6),
     (('taylor', 'protests'), 6),
     (('protests', 'art'), 6),
     (('art', 'protests'), 6),
     (('blacklivesmatter', 'breonnataylor'), 6),
     (('breonnataylor', 'louisville'), 6),
     (('louisville', 'kentucky'), 6),
     (('kentucky', 'surrealism'), 6),
     (('joebiden', 'kamalaharris'), 6),
     (('blm', 'blm'), 6),
     (('people', 'stop'), 6)]



With the 20 most frequent terms found, we can now begin creating visualizations to display our results.  A standard bar plot is certainly an option but word clouds provide a different and more visually appealing way to display terms.


```python
# Required libraries
import matplotlib.pyplot as plt

# Set keys and values
keys = TI_dict.keys()
values = TI_dict.values()

# Create bar plot
my_colors = ['blue', 'green', 'red', 'purple', 'pink', 'black', 'darkorange', 'slategray', 'brown', 'lime']
plt.figure(figsize=(14, 8))
plt.title("Top 20 Twitter Terms Associated with #BLM Query (22OCT20)", fontsize=24)
plt.bar(keys, values, color = my_colors)
plt.xticks(rotation=45)
plt.xlabel('Term', fontsize = 18)
plt.ylabel('Count', fontsize = 18)
plt.show()
```


![png](output_13_0.png)


The skewedness of the bar plot above should not be a surprise.  We did a key word query around 'BLM' so nearly every tweet contained it.  To derive a better understanding of the relativity of the other terms without 'BLM', we can repeat the process above but exclude it and 'blacklivesmatter' from our list.


```python
# Code sourced from: https://stackoverflow.com/questions/20078816/replace-non-ascii-characters-with-a-single-space
# Create an empty list for storage
temp_list = []
i = 0 # Initialize a counter
while i < len(tweet_list): # Iterate over a list
    temp_list.append(re.sub(r'[^\x00-\x7F]+',' ', tweet_list[i])) # Remove all non-ASCII characters
    #clean_list[i] = re.sub(r'^https?:\/\/.*[\r\n]*', '', clean_list[i], flags=re.MULTILINE)
    i += 1 # Increment the counter

# Code sourced from: https://stackoverflow.com/questions/11331982/how-to-remove-any-url-within-a-string-in-python
# Create an empty list for storage
clean_list = [] 
j = 0 # Initialize a counter
while j < len(temp_list): # Iterate over a list
    clean_list.append(re.sub(r'http\S+', '', temp_list[j], flags=re.MULTILINE)) # Remove any URL
    j += 1 # Increment a counter
    
# Code sourced from: https://stackoverflow.com/questions/5618878/how-to-convert-list-to-string
# Creates one long string of data
tweet_str = ''.join(str(e) for e in clean_list)

# Code sourced from OA3802_lsn10
# tokenize text
tokens_TI = nltk.word_tokenize(tweet_str)

# remove all tokens that are not alphabetic (i.e. punctuation)
words = [word for word in tokens_TI if word.isalpha()]

# Code sourced from: https://www.earthdatascience.org/courses/use-data-open-source-python/intro-to-apis/calculate-tweet-word-frequencies-in-python/
# Establish collection words to remove from our top 20 query.
collection_words = ['BLM', 'blm']

# Remove stops words from our collection word list
words = [w for w in words if not w in collection_words]
            
# put all words to lower case
words = [w.lower() for w in words]

from nltk.corpus import stopwords
stop_words = stopwords.words('english')

# Remove stops words from our TI token list
words = [w for w in words if not w in stop_words]

# Determines the frequency for each token
TI_freqs = nltk.FreqDist(words)

# Determine the top 20 terms
n = 20
TI_dict = dict(TI_freqs.most_common(n))

# Depict the top 20 terms
TI_dict
```




    {'vote': 48,
     'blacklivesmatter': 37,
     'police': 35,
     'people': 34,
     'black': 33,
     'philadelphia': 26,
     'amp': 24,
     'protests': 22,
     'antifa': 22,
     'joebiden': 20,
     'trump': 18,
     'like': 17,
     'stop': 17,
     'philly': 16,
     'biden': 15,
     'get': 15,
     'one': 15,
     'lives': 14,
     'looting': 14,
     'white': 13}




```python
# Set keys and values
keys = TI_dict.keys()
values = TI_dict.values()

# Create bar plot
my_colors = ['blue', 'green', 'red', 'purple', 'pink', 'black', 'darkorange', 'slategray', 'brown', 'lime']
plt.figure(figsize=(14, 8))
plt.title("Top 20 Twitter Terms Associated with #BLM Query (22OCT20)", fontsize=24)
plt.bar(keys, values, color = my_colors)
plt.xticks(rotation=45)
plt.xlabel('Term', fontsize = 18)
plt.ylabel('Count', fontsize = 18)
plt.show()
```


![png](output_16_0.png)


With 'BLM' and 'blm' removed, we are able to see a better picture of the most frequent words used in our tweets.  We can now generate a word cloud for a better visualization.


```python
# Required Python libraries
from wordcloud import WordCloud

# Code sourced from: https://stackoverflow.com/questions/5618878/how-to-convert-list-to-string
# Creates one long string of data
words_str = ' '.join(str(e) for e in words)

# Code sourced from: https://amueller.github.io/word_cloud/auto_examples/simple.html#sphx-glr-auto-examples-simple-py
# Creates a word cloud based upon the non-stop words of the tweets
wordcloud = WordCloud(width = 3000, height = 2000, random_state=1, background_color='white', colormap='Set1', 
                      collocations=False, stopwords = stop_words, max_words = 20).generate(words_str)

# Define a function to plot word cloud
def plot_cloud(wordcloud):
    # Set figure size
    plt.figure(figsize=(10, 8))
    # Display image
    plt.imshow(wordcloud) 
    # No axis details
    plt.axis("off");
    
# Plot
plot_cloud(wordcloud)
```


![png](output_18_0.png)


#### Task 3

We are now ready to start streaming live tweets.  In Task 1, we utilized the standard API, which collected historical tweets.  For Task 3, we'll utilize the sample streaming API to collect tweets in near-real time so that we may determine
population sentiment.  LTC Schuchard provided a listening script via `Stream_Script.py`, which will continue to run until you hit `ctrl+c`.  For this lab, I ran the script for about five minutes on the evening of the last Presidential debate.  We can also filter and search specific tweets to select English ones related to the election with code sourced from the following [link](https://stackoverflow.com/questions/26890605/filter-twitter-feeds-only-by-language).

The command `python Stream_Script.py > StreamSample.txt` is placed inside the `bash` shell and executed.

As these tweets come in JSON form, LTC Schuchard also provided a JSON converter. 


```python
import json

raw_tweets = open('StreamSample.txt', 'r') # raw file sample
tweets = [] # list container

for line in raw_tweets:
    try:
        if line.strip():
            tweets.append(json.loads(line))
    except:
        continue
```

These raw tweets required conversion to a manageable data structure.  Additionally, `tweepy` defaults to the standard mode for tweets.  As a result, the following code block creates an empty list and runs over the tweets list.  The code then extracts anything longer than one character and places the message and its user into a list of lists that is converted to a data frame.


```python
temp_tweet_list = [] # Create an empty list containter

for tweet in tweets: # Iterate over the entire list of tweets
    if len(tweet) > 1: # Checks to make sure the tweet isn't empty
        text = tweet["text"] # assigns the tweet text
        if "extended_tweet" in tweet: # Select the extended message if the tweet has the extended property. 
            text = tweet["extended_tweet"]["full_text"] #
        data = { # Select other Twitter metrics
            "User": tweet['user']['name'],
            "text": text
        }
        temp_tweet_list.append(data) # Append these data to a list

cols = ["User", "text"] # Assign column names to the forthcoming data frame

tweets_df = pd.DataFrame(temp_tweet_list, columns = cols) # Create a data frame
```

From `tweets_df`, we can draw several conclusions.
1. In the 'text' field in `tweets_df` that `Stream_Script.py` truncates some messages so a complete AFINN score is not possible.
2. This random sampling contains a lot of 'noise' such as, but not limited to, the following:
    1. Generic retweets
    2. Status updates
    3. Deleted tweets
    4. Non-ASCII characters
3. `Stream_Script.py` provides tweets in all languages and emojis.

Subsequently, we must conduct cleaning to remove this noise.


```python
# Required Python library
import string
import numpy as np
from nltk.corpus import words
# Code sourced from: https://stackoverflow.com/questions/20078816/replace-non-ascii-characters-with-a-single-space
# Code sourced from: https://stackoverflow.com/questions/36028932/how-to-extract-specific-content-in-a-pandas-dataframe-with-a-regex
# Remove all non ASCII characters from the row.
tweets_df['text'] = tweets_df['text'].str.replace(r'[^\x00-\x7F]+', '').str.strip()

# Code sourced from: https://stackoverflow.com/questions/11331982/how-to-remove-any-url-within-a-string-in-python
# Remove any URL from the row.
tweets_df['text'] = tweets_df['text'].str.replace(r'http\S+', '',).str.strip() 

# Code sourced from: https://stackoverflow.com/questions/31866196/dropping-row-containing-non-english-words-in-pandas-dataframe
# Remove any non-English tweets
Word = list(set(words.words()))
tweets_df = tweets_df[tweets_df['text'].str.contains('|'.join(Word))]

# Code sourced from: https://stackoverflow.com/questions/8376691/how-to-remove-hashtag-user-link-of-a-tweet-using-regular-expression

i = 0 # Initialize a counter
while i < len(tweets_df): # Iterate over the length of the data frame
    # Use regex to replace any '@' handles
    tweets_df.iloc[i,1] = ' '.join(re.sub("(@[A-Za-z0-9]+)|([^0-9A-Za-z \t])|(\w+:\/\/\S+)"," ",tweets_df.iloc[i,1]).split())
    i += 1 # Increment the counter

# Remove any tweets that are only RT
tweets_df['text'] = tweets_df['text'].str.replace(r'RT', '',).str.strip()

# Code sourced from: https://stackoverflow.com/questions/29314033/drop-rows-containing-empty-cells-from-a-pandas-dataframe
# Remove empty rows
tweets_df['text'].replace('', np.nan, inplace=True)
tweets_df['text'].replace(' ', np.nan, inplace=True)
tweets_df.dropna(subset=['text'], inplace=True)
```

AFINN is a list of words rated for valence with an integer between minus five (negative) and plus five for positive words.  Additional information can be found at the following [source](https://darenr.github.io/afinn/).  Due to these observations, we should expect that an AFINN score of zero dominate relative to other scores.  The following [links](https://github.com/fnielsen/afinn) provide [documentation](https://pypi.org/project/afinn/) and an easy to follow [tutorial](https://medium.com/@himanshu_23732/sentiment-analysis-with-afinn-lexicon-930533dfe75b) regarding AFINN's implementation.  We can now read in the `AFINN-111.txt` into a data frame and then convert it to a dictionary for easy hashing.


```python
# Code sourced from: https://stackoverflow.com/questions/21546739/load-data-from-txt-with-pandas
# Read in score using a delimiter of '\t'
AFINN_df = pd.read_csv('AFINN-111.txt', delimiter="\t", header = None, encoding = 'utf-8')

# Rename column headers
AFINN_df.columns = ['term', 'value']

# Convert pandas to dictionary
AFINN_dict = dict(zip(AFINN_df.term, AFINN_df.value))
```

With a clean list of tweets, we can now apply the AFINN score to each tweet to determine its sentiment.


```python
clean_list = tweets_df['text'].values.tolist()

temp_list = [] # Create temporary list for storage

i = 0 # Initialize a counter
while i < len(clean_list): # Iterate over the length of all words    
    tokens_TI = nltk.word_tokenize(clean_list[i]) # tokenize text
    words = [word for word in tokens_TI if word.isalpha()] # remove all tokens that are not alphabetic (i.e. punctuation)
    words = [w.lower() for w in words] # put all words to lower case
    j = 0
    score = 0 # Initialize a sentiment score to zero
    while j < len(words):
        #print(words[0], words[1])
        #break
        try:
            if words[j]in AFINN_dict: # If one of the words in the tweet is contained in the AFINN-111, add its score
                score += AFINN_dict[words[j]]
            else: # Otherwise add zero and continue
                score += 0
        except:
            pass
        j += 1
    temp_list.append([clean_list[i], score]) # Apprend results to the temporary list
    i += 1 # Increment the counter

# Create a data frame from temp_list
sentiment_df = pd.DataFrame(temp_list)

# Rename column headers
sentiment_df.columns = ['Tweet', 'AFINN Score']
```

We can now generate a histogram to visualize our results.


```python
# Code sourced from: https://mode.com/example-gallery/python_histogram/
ax = sentiment_df.hist(bins=25, grid=False, figsize=(12,8), color='#86bf91', zorder=2, rwidth=0.9)

ax = ax[0]
for x in ax:

    # Despine
    x.spines['right'].set_visible(False)
    x.spines['top'].set_visible(False)
    x.spines['left'].set_visible(False)

    # Switch off ticks
    x.tick_params(axis="both", which="both", bottom="off", top="off", labelbottom="on", left="off", right="off", labelleft="on")

    # Draw horizontal axis lines
    vals = x.get_yticks()
    for tick in vals:
        x.axhline(y=tick, linestyle='dashed', alpha=0.4, color='#eeeeee', zorder=1)

    # Remove title
    x.set_title("AFINN Score for Tweets Collected on 22OCT20", weight = 'bold', size = 30)

    # Set x-axis label
    x.set_xlabel("AFINN Score", labelpad=20, weight='bold', size=16)

    # Set y-axis label
    x.set_ylabel("Count", labelpad=20, weight='bold', size=16)
    
    # Code sourced from: https://stackoverflow.com/questions/21033720/python-pandas-histogram-log-scale
    x.set_yscale('log')
```


![png](output_30_0.png)


While the AFINN index provides an apparent Gaussian distribution, the original Twitter sampling contains a nontrivial amount of data that was filtered out.


```python
# Calculate the numerical difference in length
length = int(len(tweets)- len(sentiment_df))
percent_diff = round(((len(tweets) - len(sentiment_df))/len(tweets)*100),2)

print("The length of sentiment_df is ", len(sentiment_df), " and the length of the original tweet list is ", len(tweets),
     ".  The regex and ASCII filter removed ", length, " tweets or ", percent_diff, " percent.", sep = '')
```

    The length of sentiment_df is 8965 and the length of the original tweet list is 12327.  The regex and ASCII filter removed 3362 tweets or 27.27 percent.
    

Based upon the histogram above we see that zero is by far the largest AFINN score, which is not a surprise given that some tweets are incoherent, not in English, or the sentiment score evaluates to zero.

Per the lab requirements, we will now look at 10 tweets and show their scored sentiment displayed embedded within the `html` document.


```python
# Create a list of the selected ten tweets
ten_tweets = list([clean_list[20], clean_list[24], clean_list[25], clean_list[89], clean_list[705], clean_list[707],
                     clean_list[46], clean_list[64], clean_list[90], clean_list[277]])

# Print out the selected ten tweets
for i in ten_tweets:
    print("'", i, "'", sep = '')
```

    'Holy fuck I am glad I blocked this douche an unknown time ago'
    'JoeBiden epitomizes every evil we elected to eliminate the lying self serving self enriching corru'
    'This is not a win for Trump its a complete annihilation Biden hasnt had one good moment and has been crushed on every qu'
    'Barrack is no doubt not happy Alzheimer s Joe threw him under the Bus tonight'
    '2 We haven t interacted much yet but still you are berry cute yay U r adorable nd the way you give me attacks Omo I really feel loved u r lovely my darling I m here for you always nd ty for loving me ilysm I m glad I ve got u'
    'Thats very true I find it depressing because it asks us to think back on personal losses Some things you dont wanna dwell on This whole class is miserable lol but hey at least it aint math'
    'Zoom university blows man Never felt this burnt out so early in the term'
    'Stuff This could endanger the whole Caribbean please  These islands are holiday spots to you but home to us'
    'Here s the only declaration of love you ll ever catch this scorpio saying in this the time of my season I fucking LOVE MY FRIENDS'
    'silenced CDC announced this week that 130k of those deaths were really cold flu peumonia 92 000 is closer to the tru'
    


```python
# Generate a list that contains indices from our selected tweets
AFINN_index = list([20, 24, 25, 46, 64, 89, 90, 277, 705, 707]) 

# Code sourced from: https://stackoverflow.com/questions/25351968/how-to-display-full-non-truncated-dataframe-information-in-html-when-convertin
pd.set_option('display.max_colwidth', None)

# Produce a data frame with the individual tweet and its AFINN score.
sentiment_df.loc[AFINN_index]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Tweet</th>
      <th>AFINN Score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>20</th>
      <td>Holy fuck I am glad I blocked this douche an unknown time ago</td>
      <td>-5</td>
    </tr>
    <tr>
      <th>24</th>
      <td>JoeBiden epitomizes every evil we elected to eliminate the lying self serving self enriching corru</td>
      <td>-3</td>
    </tr>
    <tr>
      <th>25</th>
      <td>This is not a win for Trump its a complete annihilation Biden hasnt had one good moment and has been crushed on every qu</td>
      <td>5</td>
    </tr>
    <tr>
      <th>46</th>
      <td>Zoom university blows man Never felt this burnt out so early in the term</td>
      <td>0</td>
    </tr>
    <tr>
      <th>64</th>
      <td>Stuff This could endanger the whole Caribbean please  These islands are holiday spots to you but home to us</td>
      <td>1</td>
    </tr>
    <tr>
      <th>89</th>
      <td>Barrack is no doubt not happy Alzheimer s Joe threw him under the Bus tonight</td>
      <td>1</td>
    </tr>
    <tr>
      <th>90</th>
      <td>Here s the only declaration of love you ll ever catch this scorpio saying in this the time of my season I fucking LOVE MY FRIENDS</td>
      <td>2</td>
    </tr>
    <tr>
      <th>277</th>
      <td>silenced CDC announced this week that 130k of those deaths were really cold flu peumonia 92 000 is closer to the tru</td>
      <td>-2</td>
    </tr>
    <tr>
      <th>705</th>
      <td>2 We haven t interacted much yet but still you are berry cute yay U r adorable nd the way you give me attacks Omo I really feel loved u r lovely my darling I m here for you always nd ty for loving me ilysm I m glad I ve got u</td>
      <td>15</td>
    </tr>
    <tr>
      <th>707</th>
      <td>Thats very true I find it depressing because it asks us to think back on personal losses Some things you dont wanna dwell on This whole class is miserable lol but hey at least it aint math</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>



We can now visualize our results.


```python
# Code sourced from: https://mode.com/example-gallery/python_histogram/
ax = sentiment_df.loc[AFINN_index].hist(grid=False, figsize=(12,8), color='#86bf91', zorder=2, rwidth=0.9)

ax = ax[0]
for x in ax:

    # Despine
    x.spines['right'].set_visible(False)
    x.spines['top'].set_visible(False)
    x.spines['left'].set_visible(False)

    # Switch off ticks
    x.tick_params(axis="both", which="both", bottom="off", top="off", labelbottom="on", left="off", right="off", labelleft="on")

    # Draw horizontal axis lines
    vals = x.get_yticks()
    for tick in vals:
        x.axhline(y=tick, linestyle='dashed', alpha=0.4, color='#eeeeee', zorder=1)

    # Remove title
    x.set_title("AFINN Score for Selected Tweets Collected on 22OCT20", weight = 'bold', size = 30)

    # Set x-axis label
    x.set_xlabel("AFINN Score", labelpad=20, weight='bold', size=18)

    # Set y-axis label
    x.set_ylabel("Count", labelpad=20, weight='bold', size=18)
```


![png](output_37_0.png)


#### Task 4

Upon inspecting `sentiment_df`, we can see that Spanish, Turkish, Hindi, French, and Portuguese are merely some of the languages captured in our tweets.  Based off of our previous computation, we see that the cleaning process removed approximately 27.27% of tweets that either contained emojis or not in the English language.  While not English, the aforementioned languages can use Latin script for conversion to English characters.  As a result, they are not filtered out through our previous methods.

Additionally, `sentiment_df` contains a multitude of tweets that are strictly punctuation, blank, or simple retweets to other users, which are also not previously filtered out.  Removing these tweets are relatively straight forward processes with minimal lines of code and aids in our ability to develop a truer sentiment analysis.


```python
# Code sourced from: https://stackoverflow.com/questions/265960/best-way-to-strip-punctuation-from-a-string
# Establish a set of punctuation to exclude
exclude = set(string.punctuation)

i = 0 # Initialize a counter
while i < len(clean_list): # Iterate over the entire list # Remove any punctuation from a tweet
    clean_list[i] = ''.join(ch for ch in clean_list[i] if ch not in exclude)
    i += 1  # Increment a counter
    
# Code sourced from: https://stackoverflow.com/questions/41290028/removing-non-english-words-from-text-using-python
words = set(nltk.corpus.words.words())

i = 0 # Initialize a counter
while i < len(clean_list): # Iterate over the length of the list
    clean_list[i] = " ".join(w for w in nltk.wordpunct_tokenize(clean_list[i]) \
         if w.lower() in words or not w.isalpha())  # Remove any non-English words
    i += 1 # Increment the counter

# Code sourced from: https://stackoverflow.com/questions/8449454/remove-strings-containing-only-white-spaces-from-list
# Remove any tweets that only contain spaces
clean_list = [tweet for tweet in clean_list if tweet.strip()]
clean_list = list(filter(lambda tweet: tweet.strip(), clean_list))

# Code sourced from: https://stackoverflow.com/questions/16084642/remove-strings-from-a-list-that-contains-numbers-in-python
# Filter out tweets that are only numbers
clean_list = [x for x in clean_list if not any(c.isdigit() for c in x)]

# Since the smallest word in the ANIFF-111.txt is of length 2, we can remove any string that is one character or less.
i = 0 # Initialize a counter
while i < len(clean_list):
    clean_list[i] = re.sub(r'\b\w{1}\b', '', clean_list[i])
    i += 1

# Code sourced from: https://stackoverflow.com/questions/3845423/remove-empty-strings-from-a-list-of-strings
# Filter out blank tweets
clean_list = list(filter(None, clean_list))
```

We can now apply our sentiment analysis as we previously did with our original list.


```python
temp_list = [] # Create temporary list for storage

i = 0 # Initialize a counter
while i < len(clean_list): # Iterate over the length of all words    
    tokens_TI = nltk.word_tokenize(clean_list[i]) # tokenize text
    words = [word for word in tokens_TI if word.isalpha()] # remove all tokens that are not alphabetic (i.e. punctuation)
    words = [w.lower() for w in words] # put all words to lower case
    j = 0
    score = 0 # Initialize a sentiment score to zero
    while j < len(words):
        #print(words[0], words[1])
        #break
        try:
            if words[j]in AFINN_dict: # If one of the words in the tweet is contained in the AFINN-111, add its score
                score += AFINN_dict[words[j]]
            else: # Otherwise add zero and continue
                score += 0
        except:
            pass
        j += 1
    temp_list.append([clean_list[i], score]) # Apprend results to the temporary list
    i += 1 # Increment the counter

# Create a data frame from temp_list
sentiment_df = pd.DataFrame(temp_list)

# Rename column headers
sentiment_df.columns = ['Tweet', 'AFINN Score']
```

We can now visualize our `sentiment_df`.


```python
# Code sourced from: https://mode.com/example-gallery/python_histogram/
ax = sentiment_df.hist(bins=25, grid=False, figsize=(12,8), color='#86bf91', zorder=2, rwidth=0.9)

ax = ax[0]
for x in ax:

    # Despine
    x.spines['right'].set_visible(False)
    x.spines['top'].set_visible(False)
    x.spines['left'].set_visible(False)

    # Switch off ticks
    x.tick_params(axis="both", which="both", bottom="off", top="off", labelbottom="on", left="off", right="off", labelleft="on")

    # Draw horizontal axis lines
    vals = x.get_yticks()
    for tick in vals:
        x.axhline(y=tick, linestyle='dashed', alpha=0.4, color='#eeeeee', zorder=1)

    # Remove title
    x.set_title("AFINN Score for Tweets Collected on 22OCT20", weight = 'bold', size = 30)

    # Set x-axis label
    x.set_xlabel("AFINN Score", labelpad=20, weight='bold', size=16)

    # Set y-axis label
    x.set_ylabel("Count", labelpad=20, weight='bold', size=16)
    
    # Code sourced from: https://stackoverflow.com/questions/21033720/python-pandas-histogram-log-scale
    x.set_yscale('log')
```


![png](output_43_0.png)


#### Analysis
We can see by the histogram above that the cleaning and filtering reduced our zero score by nearly a factor of 10.  This reduction significantly increased our understanding of the captured sentiment.  However, upon inspection there are still tweets that are incoherent and score zero.  

As a result of data cleaning, I believe zero dominates as the leading score for the following reasons:
1. Despite filtering attempts to remove non-English words, there are tweets that are in other languages.
2. Concise tweets such as 'was', 'oh', and 'over it' are not scored on the AFINN scale.
3. Although some sentences are longer and allow for evaluation, the positivity and negativity may offset each other and equal zero.

I do believe it is possible to draw conclusions based on the histogram above.  The distribution appears normal and some napkin math to approximate the actual number of tweets with an AFINN score of zero would allow an analyst to study and apply statistical methods such as confidence and prediction intervals.

However, these tweets occurred immediately following the last presidential debate, which may influence and skew the results.  For example, people tend to express strong emotions and opinions when discussing politics.  As such, the distribution's tails may not be as heavily skewed.  An additional possibility is that the variance might be smaller and we would see values closer to zero during non-election or non-debate time periods.


```python
# Code sourced from: https://stackoverflow.com/questions/5618878/how-to-convert-list-to-string
# Creates one long string of data
tweet_str = ''.join(str(e) for e in clean_list)

# Code sourced from OA3802_lsn10
# tokenize text
tokens_TI = nltk.word_tokenize(tweet_str)

# remove all tokens that are not alphabetic (i.e. punctuation)
words = [word for word in tokens_TI if word.isalpha()]

# put all words to lower case
words = [w.lower() for w in words]

from nltk.corpus import stopwords
stop_words = stopwords.words('english')

# Remove stops words from our TI token list
words = [w for w in words if not w in stop_words]

# Determines the frequency for each token
TI_freqs = nltk.FreqDist(words)

# Determine the top 20 terms
n = 20
TI_dict = dict(TI_freqs.most_common(n))

# Depict the top 20 terms
TI_dict
```




    {'de': 363,
     'like': 156,
     'la': 145,
     'trump': 137,
     'en': 134,
     'se': 112,
     'el': 106,
     'one': 105,
     'eu': 99,
     'love': 94,
     'debate': 83,
     'te': 79,
     'es': 78,
     'get': 78,
     'know': 76,
     'da': 74,
     'dont': 74,
     'good': 72,
     'un': 66,
     'con': 66}




```python
# Set keys and values
keys = TI_dict.keys()
values = TI_dict.values()

# Create bar plot
my_colors = ['blue', 'green', 'red', 'purple', 'pink', 'black', 'darkorange', 'slategray', 'brown', 'lime']
plt.figure(figsize=(14, 8))
plt.title("Top 20 Twitter Terms Associated with Live Stream (22OCT20)", fontsize=24)
plt.bar(keys, values, color = my_colors)
plt.xticks(rotation=45)
plt.xlabel('Term', fontsize = 18)
plt.ylabel('Count', fontsize = 18)
plt.show()
```


![png](output_46_0.png)


We can see from the bar plot above that there are several terms that although present themselves as English and subsequently slip through our filtering parameters, they should be removed.


```python
# Code sourced from: https://stackoverflow.com/questions/5618878/how-to-convert-list-to-string
# Creates one long string of data
tweet_str = ''.join(str(e) for e in clean_list)

# Code sourced from OA3802_lsn10
# tokenize text
tokens_TI = nltk.word_tokenize(tweet_str)

# remove all tokens that are not alphabetic (i.e. punctuation)
words = [word for word in tokens_TI if word.isalpha()]

# Code sourced from: https://www.earthdatascience.org/courses/use-data-open-source-python/intro-to-apis/calculate-tweet-word-frequencies-in-python/
# Establish collection words to remove from our top 20 query.
collection_words = ['de', 'la', 'en', 'se', 'el', 'eu', 'es', 'para', 'na', 'te', 'con', 'ta', 'un', 'da']

# Remove stops words from our collection word list
words = [w for w in words if not w in collection_words]
            
# put all words to lower case
words = [w.lower() for w in words]

from nltk.corpus import stopwords
stop_words = stopwords.words('english')

# Remove stops words from our TI token list
words = [w for w in words if not w in stop_words]

# Determines the frequency for each token
TI_freqs = nltk.FreqDist(words)

# Determine the top 20 terms
n = 20
TI_dict = dict(TI_freqs.most_common(n))

# Depict the top 20 terms
TI_dict
```




    {'like': 156,
     'trump': 137,
     'one': 105,
     'love': 94,
     'debate': 83,
     'get': 78,
     'know': 76,
     'dont': 74,
     'good': 72,
     'people': 65,
     'joe': 64,
     'new': 61,
     'lo': 59,
     'us': 58,
     'would': 57,
     'time': 56,
     'really': 56,
     'president': 56,
     'best': 55,
     'never': 55}



We can now produce our final bar plot.


```python
# Set keys and values
keys = TI_dict.keys()
values = TI_dict.values()

# Create bar plot
my_colors = ['blue', 'green', 'red', 'purple', 'pink', 'black', 'darkorange', 'slategray', 'brown', 'lime']
plt.figure(figsize=(14, 8))
plt.title("Top 20 Twitter Terms Associated with Live Stream (22OCT20)", fontsize=24)
plt.bar(keys, values, color = my_colors)
plt.xticks(rotation=45)
plt.xlabel('Term', fontsize = 18)
plt.ylabel('Count', fontsize = 18)
plt.show()
```


![png](output_50_0.png)



```python
# Take a bi-gram perspective
bigrams = nltk.bigrams(words)

#compute frequency distribution for all the bigrams in the text
bigrams_freq = nltk.FreqDist(bigrams)

# Depict the top 20 bigrams
bigrams_freq.most_common(n)
```




    [(('happy', 'birthday'), 28),
     (('feeling', 'little'), 16),
     (('officially', 'hope'), 15),
     (('hope', 'find'), 15),
     (('find', 'positivity'), 15),
     (('positivity', 'welcoming'), 15),
     (('welcoming', 'feeling'), 15),
     (('little', 'world'), 15),
     (('world', 'music'), 15),
     (('rebel', 'star'), 13),
     (('feel', 'like'), 12),
     (('president', 'trump'), 11),
     (('massacre', 'going'), 11),
     (('oil', 'industry'), 10),
     (('please', 'spread'), 10),
     (('win', 'trump'), 9),
     (('trump', 'complete'), 9),
     (('complete', 'annihilation'), 9),
     (('annihilation', 'one'), 9),
     (('one', 'good'), 9)]




```python
# Code sourced from: https://stackoverflow.com/questions/5618878/how-to-convert-list-to-string
# Creates one long string of data
words_str = ' '.join(str(e) for e in words)

# Code sourced from: https://amueller.github.io/word_cloud/auto_examples/simple.html#sphx-glr-auto-examples-simple-py
# Creates a word cloud based upon the non-stop words of the tweets
wordcloud = WordCloud(width = 3000, height = 2000, random_state=1, background_color='Salmon', colormap='Set2', 
                      collocations=False, stopwords = stop_words, max_words = 20).generate(words_str)

# Define a function to plot word cloud
def plot_cloud(wordcloud):
    # Set figure size
    plt.figure(figsize=(10, 8))
    # Display image
    plt.imshow(wordcloud) 
    # No axis details
    plt.axis("off");
    
# Plot
plot_cloud(wordcloud)
```


![png](output_52_0.png)


We can see from the bar plot and the word cloud that "Trump" and "like" are the two leading terms within our Twitter stream.  However, we cannot draw the conclusion that Twitter users liked Trump's performance Thursday evening or they are his supporters.  Conversely, "Joe" was tweeted less times than Trump, which is not necessarily an indicator of his poor performance or lack of support.

When we analyze our bigram, we can see that President Trump and his performance was frequently tweeted about.  While political pundits may analyze and determine who won the debate, Twitter users tweeted nearly twice as much about President Trump than former Vice President Biden.

Overall I found the sentiment to be fairly subjective and unable to grasp context.  One user we previously looked at tweeted "Barrack is no doubt not happy Alzheimer s Joe threw him under the Bus tonight," which can be interpreted positively or negatively depending on an individual's political leanings yet it scored only one on the AFINN scale.  Another user tweeted "Zoom university blows man. Never felt this burnt out so early in the term," which also scored zero but could be interpreted as a negative statement about this student's mental health and well-being.  Moreover, AFINN is unable to account for misspellings, which impacts the overall sentiment.

The following [link](https://www.statedecoded.com/2012/03/messy/) is a reminder that even though an analyst can do all that he or she can, their data munging and subsequent results may not be perfect.  Twitter data is especially difficult to work with and to correct given its pervaise use and seemingly infinite string input possibilities.  For example, the previous `regex` and cleaning filters removed valid tweets that contained emojis.  Emojis are [ubiquitous](https://www.statista.com/chart/17275/number-of-emojis-from-1995-bis-2019/#:~:text=Today%20it%20is%20estimated%20that,according%20to%20the%20social%20network.) and often represent positive and negative sentiment that was missed via our scraping efforts.  The next iteration of AFINN should incorporate emojis, which would provide a better sentiment representation.

